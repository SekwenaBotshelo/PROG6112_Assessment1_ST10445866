/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog6112practicalassignment;

/**
 *
 * @author koketso
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Prog6112PracticalAssignment {
    private static ArrayList<SeriesModel> seriesList = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        displayWelcomeScreen();
    }

    private static void displayWelcomeScreen() {
        System.out.println("****************************************************");
        System.out.println("LATEST SERIES - 2025");
        System.out.println("****************************************************");
        System.out.println("Enter (1) to launch menu or any other key to exit");

        String input = scanner.nextLine();
        if (input.equals("1")) {
            displayMainMenu();
        } else {
            System.out.println("Exiting application...");
            System.exit(0);
        }
    }

    private static void displayMainMenu() {
        while (true) {
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Capture a new series");
            System.out.println("(2) Search for a series");
            System.out.println("(3) Update series age restriction");
            System.out.println("(4) Delete a series");
            System.out.println("(5) Print series report - 2025");
            System.out.println("(6) Exit Application");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    captureNewSeries();
                    break;
                case 2:
                    searchSeries();
                    break;
                case 3:
                    updateSeriesAge();
                    break;
                case 4:
                    deleteSeries();
                    break;
                case 5:
                    printSeriesReport();
                    break;
                case 6:
                    System.out.println("Exiting application...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option! Try again.");
            }
        }
    }

    // --- Helper Methods (unchanged) ---
    private static void captureNewSeries() {
    System.out.println("\n--- Capture New Series ---");
    
    System.out.print("Enter Series ID: ");
    String id = scanner.nextLine();

    System.out.print("Enter Series Name: ");
    String name = scanner.nextLine();

    // Use the reusable validation method
    String age = validateAgeRestriction(scanner);

    System.out.print("Enter Number of Episodes: ");
    String episodes = scanner.nextLine();

    SeriesModel newSeries = new SeriesModel(id, name, age, episodes);
    seriesList.add(newSeries);
    
    // Enhanced success message (without "S" prefix)
    System.out.println("\nSeries successfully saved:");
    System.out.println("ID: " + id); // Displays "103" instead of "S103"
    System.out.println("Name: " + name);
    System.out.println("Age Restriction: " + age);
    System.out.println("Episodes: " + episodes);
}

    private static void searchSeries() {
        System.out.println("\n--- Search for a Series ---");
        System.out.print("Enter Series Name or ID: ");
        String searchTerm = scanner.nextLine();

        boolean found = false;
        for (SeriesModel series : seriesList) {
            if (series.getSeriesName().equalsIgnoreCase(searchTerm) || 
                series.getSeriesId().equalsIgnoreCase(searchTerm)) {
                System.out.println(series);
                found = true;
            }
        }

        if (!found) {
            System.out.println("Series not found!");
        }
    }

    private static void updateSeriesAge() {
    System.out.println("\n--- Update Age Restriction ---");
    System.out.print("Enter Series ID to update: ");
    String id = scanner.nextLine();

    for (SeriesModel series : seriesList) {
        if (series.getSeriesId().equalsIgnoreCase(id)) {
            // Use the same validation method
            String newAge = validateAgeRestriction(scanner);
            series.setSeriesAge(newAge);
            System.out.println("Age restriction updated!");
            return;
        }
    }
    System.out.println("Series not found!");
}

    private static void deleteSeries() {
    System.out.println("\n--- Delete a Series ---");
    System.out.print("Enter Series ID to delete: ");
    String id = scanner.nextLine(); // Fixed typo: "ne1 xtLine()" → "nextLine()"

    for (int i = 0; i < seriesList.size(); i++) {
        if (seriesList.get(i).getSeriesId().equalsIgnoreCase(id)) {
            seriesList.remove(i);
            System.out.println("Series deleted!");
            return;
        }
    }
    System.out.println("Series not found!");
}

    private static void printSeriesReport() {
    System.out.println("\n--- SERIES REPORT (2025) ---");
    System.out.println("+------------+----------------------+------------+-----------------+");
    System.out.println("| Series ID  | Series Name          | Age Rating | Episodes        |");
    System.out.println("+------------+----------------------+------------+-----------------+");

    if (seriesList.isEmpty()) {
        System.out.println("|          No series found in the database.                     |");
    } else {
        for (SeriesModel series : seriesList) {
            System.out.format(
                "| %-10s | %-20s | %-10s | %-15s |\n",
                series.getSeriesId(),
                series.getSeriesName(),
                series.getSeriesAge() + "+",
                series.getSeriesNumberOfEpisodes()
            );
        }
    }
    System.out.println("+------------+----------------------+------------+-----------------+");
}
    
    private static String validateAgeRestriction(Scanner scanner) {
    String age;
    while (true) {
        System.out.print("Enter Age Restriction (2-18, numbers only): ");
        age = scanner.nextLine();
        try {
            int ageNum = Integer.parseInt(age);
            if (ageNum >= 2 && ageNum <= 18) {
                return age; // Valid input, return the age
            } else {
                System.out.println("Error: Age must be between 2 and 18. Try again.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Error: Only numbers are allowed. Try again.");
        }
    }
}
}
