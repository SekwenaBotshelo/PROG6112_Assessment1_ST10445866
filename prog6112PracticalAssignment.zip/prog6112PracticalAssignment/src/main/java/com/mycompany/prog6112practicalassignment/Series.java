/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog6112practicalassignment;

/**
 *
 * @author koketso
 */
public class Series {
    private String title;
    private String genre;
    private int ageRestriction;
    private int releaseYear;
    private double rating;

    // Constructor
    public Series(String title, String genre, int ageRestriction, int releaseYear, double rating) {
        this.title = title;
        this.genre = genre;
        this.ageRestriction = ageRestriction;
        this.releaseYear = releaseYear;
        this.rating = rating;
    }

    // Getters and Setters
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }

    public int getAgeRestriction() { return ageRestriction; }
    public void setAgeRestriction(int ageRestriction) { this.ageRestriction = ageRestriction; }

    public int getReleaseYear() { return releaseYear; }
    public void setReleaseYear(int releaseYear) { this.releaseYear = releaseYear; }

    public double getRating() { return rating; }
    public void setRating(double rating) { this.rating = rating; }

    @Override
    public String toString() {
        return String.format(
            "Title: %s | Genre: %s | Age Restriction: %d+ | Year: %d | Rating: %.1f",
            title, genre, ageRestriction, releaseYear, rating
        );
    }
}
