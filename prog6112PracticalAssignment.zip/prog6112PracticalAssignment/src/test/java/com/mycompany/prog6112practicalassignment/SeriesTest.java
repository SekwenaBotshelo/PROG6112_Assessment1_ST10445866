/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.prog6112practicalassignment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author koketso
 */
import java.util.ArrayList;

public class SeriesTest {
    
    private ArrayList<SeriesModel> seriesList;

    @BeforeEach
    void setUp() {
        seriesList = new ArrayList<>();
        seriesList.add(new SeriesModel("S101", "Breaking Bad", "18", "62"));
        seriesList.add(new SeriesModel("S102", "Stranger Things", "16", "34"));
    }

    // --- Helpers for testing ---
    private SeriesModel searchSeries(ArrayList<SeriesModel> list, String searchTerm) {
        for (SeriesModel s : list) {
            if (s.getSeriesId().equalsIgnoreCase(searchTerm) ||
                s.getSeriesName().equalsIgnoreCase(searchTerm)) {
                return s;
            }
        }
        return null;
    }

    private boolean updateSeriesAge(ArrayList<SeriesModel> list, String id, String newAge) {
        for (SeriesModel s : list) {
            if (s.getSeriesId().equalsIgnoreCase(id)) {
                s.setSeriesAge(newAge);
                return true;
            }
        }
        return false;
    }

    private boolean deleteSeries(ArrayList<SeriesModel> list, String id) {
        return list.removeIf(s -> s.getSeriesId().equalsIgnoreCase(id));
    }

    private boolean validateAgeRestriction(int age) {
        return (age >= 2 && age <= 18);
    }

    // --- TEST CASES ---

    @Test
    void TestSearchSeries() {
        SeriesModel result = searchSeries(seriesList, "S101");
        assertNotNull(result);
        assertEquals("Breaking Bad", result.getSeriesName());
    }

    @Test
    void TestSearchSeries_SeriesNotFound() {
        SeriesModel result = searchSeries(seriesList, "S999");
        assertNull(result);
    }

    @Test
    void TestUpdateSeries() {
        boolean updated = updateSeriesAge(seriesList, "S102", "12");
        assertTrue(updated);
        assertEquals("12", searchSeries(seriesList, "S102").getSeriesAge());
    }

    @Test
    void TestDeleteSeries() {
        boolean deleted = deleteSeries(seriesList, "S101");
        assertTrue(deleted);
        assertNull(searchSeries(seriesList, "S101"));
    }

    @Test
    void TestDeleteSeries_SeriesNotFound() {
        boolean deleted = deleteSeries(seriesList, "S999");
        assertFalse(deleted);
    }

    @Test
    void TestSeriesAgeRestriction_AgeValid() {
        assertTrue(validateAgeRestriction(15));
        assertTrue(validateAgeRestriction(2));
        assertTrue(validateAgeRestriction(18));
    }

    @Test
    void TestSeriesAgeRestriction_SeriesAgeInValid() {
        assertFalse(validateAgeRestriction(1));
        assertFalse(validateAgeRestriction(19));
        assertFalse(validateAgeRestriction(-5));
    }
}
