/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.retailinventoryapp.st10445866;

/**
 *
 * @author koketso
 */
import java.util.ArrayList;

public class Inventory {

    private Product[] products;
    private int count;
    private ArrayList<String> transactions;

    public Inventory(int size) {
        products = new Product[size];
        count = 0;
        transactions = new ArrayList<>();
    }

    // Adding a product
    public void addProduct(Product p) {
        if (count < products.length) {
            products[count++] = p;
            String message = "✅ Added: " + p.getName() + " (Stock: " + p.getStock() + ")";
            System.out.println(message);
            transactions.add(message);

            if (p.getStock() == 0) {
                System.out.println("🔴 Stock for " + p.getName() + " is 0! Please restock.");
            }
        } else {
            System.out.println("❌ Inventory full! Cannot add more products.");
        }
    }

    // Selling a product
    public void sellProduct(String name, int qty) {
        Product p = getProductByName(name);
        if (p == null) {
            System.out.println("❌ Product not found!");
            return;
        }

        if (qty > p.getStock()) {
            System.out.println("❌ Not enough stock. Available: " + p.getStock());
            return;
        }

        p.setStock(p.getStock() - qty);
        System.out.println("✅ Sold " + qty + " of " + name + ". Remaining stock: " + p.getStock());
        transactions.add("Sold " + qty + " of " + name);

        if (p.getStock() == 0) {
            System.out.println("🔴 Stock for " + name + " has run out! Please restock.");
        } else if (p.getStock() < 5) {
            System.out.println("⚠️ LOW STOCK! Remaining: " + p.getStock());
        }
    }

    // Get product by name
    public Product getProductByName(String name) {
        for (int i = 0; i < count; i++) {
            if (products[i].getName().equalsIgnoreCase(name)) {
                return products[i];
            }
        }
        return null;
    }

    // Showing the inventory report
    public void showReport() {
        System.out.println("\n===== INVENTORY REPORT =====");

        double electronicsValue = 0, groceriesValue = 0;

        System.out.println("\n--- Electronics ---");
        boolean hasElectronics = false;
        for (int i = 0; i < count; i++) {
            if (products[i] instanceof Electronics) {
                System.out.print(products[i].getReport());
                if (products[i].getStock() == 0) System.out.print(" 🔴 OUT OF STOCK!");
                else if (products[i].getStock() < 5) System.out.print(" ⚠️ LOW STOCK!");
                System.out.println();
                electronicsValue += products[i].getPrice() * products[i].getStock();
                hasElectronics = true;
            }
        }
        if (!hasElectronics) System.out.println("No electronics in inventory.");
        else System.out.println("Electronics Total Value: R" + electronicsValue);

        System.out.println("\n--- Groceries ---");
        boolean hasGroceries = false;
        for (int i = 0; i < count; i++) {
            if (products[i] instanceof Grocery) {
                System.out.print(products[i].getReport());
                if (products[i].getStock() == 0) System.out.print(" 🔴 OUT OF STOCK!");
                else if (products[i].getStock() < 5) System.out.print(" ⚠️ LOW STOCK!");
                System.out.println();
                groceriesValue += products[i].getPrice() * products[i].getStock();
                hasGroceries = true;
            }
        }
        if (!hasGroceries) System.out.println("No groceries in inventory.");
        else System.out.println("Groceries Total Value: R" + groceriesValue);

        System.out.println("\nOverall Inventory Value: R" + (electronicsValue + groceriesValue));
        System.out.println("============================");
    }

    // Showing the transaction history
    public void showTransactions() {
        System.out.println("\n===== TRANSACTION HISTORY =====");
        if (transactions.isEmpty()) {
            System.out.println("No transactions recorded yet.");
        } else {
            for (String log : transactions) {
                System.out.println(log);
            }
        }
        System.out.println("===============================");
    }
}

