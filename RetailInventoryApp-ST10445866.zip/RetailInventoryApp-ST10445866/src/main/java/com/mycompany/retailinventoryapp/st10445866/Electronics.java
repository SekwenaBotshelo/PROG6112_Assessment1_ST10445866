/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.retailinventoryapp.st10445866;

/**
 *
 * @author koketso
 */
public class Electronics extends Product {
    private int warranty; // In months

    public Electronics(String name, double price, int stock, int warranty) {
        super(name, price, stock);
        this.warranty = warranty;
    }

    // Getter for warranty
    public int getWarranty() {
        return warranty;
    }

    @Override
    public String getReport() {
        return getName() + " | Price: R" + getPrice() + " | Stock: " + getStock() + " | Warranty: " + warranty + " months";
    }
}

