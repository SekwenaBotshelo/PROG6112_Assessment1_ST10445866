/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.retailinventoryapp.st10445866;

/**
 *
 * @author koketso
 */
public class Grocery extends Product {
    private String expiryDate;

    public Grocery(String name, double price, int stock, String expiryDate) {
        super(name, price, stock);
        this.expiryDate = expiryDate;
    }

    // Getter for expiry date
    public String getExpiryDate() {
        return expiryDate;
    }

    @Override
    public String getReport() {
        return getName() + " | Price: R" + getPrice() + " | Stock: " + getStock() + " | Expiry: " + expiryDate;
    }
}

