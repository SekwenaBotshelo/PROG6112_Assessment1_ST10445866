/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.retailinventoryapp.st10445866;

/**
 *
 * @author koketso
 */
import java.util.Scanner;

public class RetailInventoryAppST10445866 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Inventory store = new Inventory(20);
        InputHelper input = new InputHelper(sc);

        // --- Preload Electronics ---
        store.addProduct(new Electronics("Laptop", 12000, 5, 24));
        store.addProduct(new Electronics("Smartphone", 8000, 10, 12));
        store.addProduct(new Electronics("Tablet", 6000, 7, 18));
        store.addProduct(new Electronics("Smartwatch", 3500, 8, 12));
        store.addProduct(new Electronics("VR Headset", 15000, 3, 24));

        // --- Preload Groceries ---
        store.addProduct(new Grocery("Milk", 25, 30, "2025-12-01"));
        store.addProduct(new Grocery("Bread", 15, 20, "2025-09-05"));
        store.addProduct(new Grocery("Eggs", 40, 50, "2025-09-15"));
        store.addProduct(new Grocery("Apple", 10, 25, "2025-11-01"));
        store.addProduct(new Grocery("Orange Juice", 35, 15, "2025-10-10"));

        int choice;

        do {
            System.out.println("\n=== Retail Inventory System ===");
            System.out.println("1. View Report");
            System.out.println("2. Sell Product");
            System.out.println("3. Add Product");
            System.out.println("4. View Transactions");
            System.out.println("5. Search Product");
            System.out.println("6. Exit");

            choice = input.getInt("Enter choice: ", 1, 6);

            switch (choice) {
                case 1:
                    store.showReport();
                    break;

                case 2:
                    String sellName = input.getString("Enter product name to sell: ");
                    Product p = store.getProductByName(sellName);
                    if (p == null) {
                        System.out.println("❌ Product not found!");
                        break;
                    }

                    int qty;
                    do {
                        qty = input.getInt("Enter quantity to sell: ", 1, Integer.MAX_VALUE);
                        if (qty > p.getStock()) {
                            System.out.println("❌ Not enough stock. Available: " + p.getStock());
                        }
                    } while (qty > p.getStock());

                    store.sellProduct(sellName, qty);
                    break;

                case 3:
                    int type = input.getInt("Enter product type (1=Electronics, 2=Grocery): ", 1, 2);
                    String name = input.getString("Enter product name: ");
                    double price = input.getDouble("Enter price: ", 0.01);
                    int stock = input.getInt("Enter stock: ", 1, 10000);

                    if (type == 1) {
                        int warranty = input.getInt("Enter warranty months: ", 1, 60);
                        store.addProduct(new Electronics(name, price, stock, warranty));
                    } else {
                        String expiry = input.getDate("Enter expiry date (YYYY-MM-DD): ");
                        store.addProduct(new Grocery(name, price, stock, expiry));
                    }
                    break;

                case 4:
                    store.showTransactions();
                    break;

                case 5:
                    String searchName = input.getString("Enter product name to search: ");
                    Product result = store.getProductByName(searchName);

                    if (result != null) {
                        System.out.println("\n--- Product Found ---");
                        System.out.println("Name: " + result.getName());
                        System.out.println("Price: R" + result.getPrice());

                        // Show stock with warning if necessary
                        if (result.getStock() == 0) System.out.println("Stock: 0 🔴 OUT OF STOCK!");
                        else if (result.getStock() < 5) System.out.println("Stock: " + result.getStock() + " ⚠️ LOW STOCK!");
                        else System.out.println("Stock: " + result.getStock());

                        if (result instanceof Electronics) {
                            System.out.println("Category: Electronics");
                            System.out.println("Warranty: " + ((Electronics) result).getWarranty() + " months");
                        } else if (result instanceof Grocery) {
                            System.out.println("Category: Grocery");
                            System.out.println("Expiry Date: " + ((Grocery) result).getExpiryDate());
                        }
                    } else {
                        System.out.println("❌ Product not found!");
                    }
                    break;

                case 6:
                    System.out.println("Exiting... Goodbye!");
                    break;
            }

        } while (choice != 6);

        sc.close();
    }
}
