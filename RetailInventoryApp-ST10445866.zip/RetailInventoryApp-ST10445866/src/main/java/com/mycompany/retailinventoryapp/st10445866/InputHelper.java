/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.retailinventoryapp.st10445866;

/**
 *
 * @author koketso
 */
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

public class InputHelper {
    private Scanner sc;

    public InputHelper(Scanner sc) {
        this.sc = sc;
    }

    public int getInt(String prompt, int min, int max) {
        int value;
        while (true) {
            try {
                System.out.print(prompt);
                value = Integer.parseInt(sc.nextLine());
                if (value < min || value > max) {
                    System.out.println("❌ Please enter a value between " + min + " and " + max);
                } else {
                    return value;
                }
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid number, please try again.");
            }
        }
    }

    public double getDouble(String prompt, double min) {
        double value;
        while (true) {
            try {
                System.out.print(prompt);
                value = Double.parseDouble(sc.nextLine());
                if (value < min) {
                    System.out.println("❌ Please enter a value greater than " + min);
                } else {
                    return value;
                }
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid number, please try again.");
            }
        }
    }

    public String getDate(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                String input = sc.nextLine();
                LocalDate.parse(input); // validate format
                return input;
            } catch (DateTimeParseException e) {
                System.out.println("❌ Invalid date format. Please use YYYY-MM-DD.");
            }
        }
    }

    public String getString(String prompt) {
        System.out.print(prompt);
        return sc.nextLine();
    }
}
