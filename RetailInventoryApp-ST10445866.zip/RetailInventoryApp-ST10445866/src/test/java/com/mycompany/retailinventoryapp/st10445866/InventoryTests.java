/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

package com.mycompany.retailinventoryapp.st10445866;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
/**
 *
 * @author koketso
 */
public class InventoryTests {
    
    private Inventory store;
    private Electronics laptop;
    private Grocery milk;

    @BeforeEach
    void setUp() {
        store = new Inventory(5);
        laptop = new Electronics("Laptop", 12000.0, 5, 24);
        milk = new Grocery("Milk", 25.0, 30, "2025-12-01");

        store.addProduct(laptop);
        store.addProduct(milk);
    }

    @Test
    void testAddProduct() {
        Electronics phone = new Electronics("Phone", 8000.0, 10, 12);
        store.addProduct(phone);
        assertEquals(phone, store.getProductByName("Phone"));
    }

    @Test
    void testAddProductInventoryFull() {
    // Already 2 products from setUp: Laptop, Milk
    store.addProduct(new Electronics("Tablet", 6000, 7, 18)); // 3rd
    store.addProduct(new Grocery("Bread", 15, 20, "2025-09-05")); // 4th
    store.addProduct(new Grocery("Eggs", 40, 50, "2025-09-15")); // 5th, reaches capacity

    // Try to add 6th product, should NOT be added
    Grocery orange = new Grocery("Orange", 10, 5, "2025-10-01");
    store.addProduct(orange);

    // Assert that the last product was NOT added
    assertNull(store.getProductByName("Orange")); // Orange exceeds inventory capacity
}

    @Test
    void testSellProduct() {
        store.sellProduct("Laptop", 3);
        assertEquals(2, laptop.getStock());

        // Selling more than available stock
        store.sellProduct("Laptop", 5);
        assertEquals(2, laptop.getStock());
    }

    @Test
    void testGetProductByName() {
        assertEquals(laptop, store.getProductByName("Laptop"));
        assertEquals(milk, store.getProductByName("Milk"));
        assertNull(store.getProductByName("Nonexistent"));
    }

    @Test
    void testTransactionHistory() {
        store.sellProduct("Laptop", 2);
        store.sellProduct("Milk", 5);

        ArrayList<String> transactions = new ArrayList<>();
        transactions.add("Sold 2 of Laptop");
        transactions.add("Sold 5 of Milk");

        // Note: You could add a getter in Inventory for transactions for proper testing
        // For simplicity, we can check stock changes
        assertEquals(3, laptop.getStock());
        assertEquals(25, milk.getStock());
    }
}
