/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

package com.mycompany.retailinventoryapp.st10445866;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author koketso
 */
public class ProductTests {
    
    private Product genericProduct;
    private Electronics laptop;
    private Grocery milk;

    @BeforeEach
    void setUp() {
        genericProduct = new Product("Generic", 100.0, 10);
        laptop = new Electronics("Laptop", 12000.0, 5, 24);
        milk = new Grocery("Milk", 25.0, 30, "2025-12-01");
    }

    // --- Product tests ---
    @Test
    void testProductGetters() {
        assertEquals("Generic", genericProduct.getName());
        assertEquals(100.0, genericProduct.getPrice());
        assertEquals(10, genericProduct.getStock());
    }

    @Test
    void testProductSell() {
        genericProduct.sell(3);
        assertEquals(7, genericProduct.getStock());

        // Cannot sell more than stock
        genericProduct.sell(10);
        assertEquals(7, genericProduct.getStock());
    }

    // --- Electronics tests ---
    @Test
    void testElectronicsWarranty() {
        assertEquals(24, laptop.getWarranty());
    }

    @Test
    void testElectronicsReport() {
        String report = laptop.getReport();
        assertTrue(report.contains("Laptop"));
        assertTrue(report.contains("12000"));
        assertTrue(report.contains("Warranty"));
    }

    // --- Grocery tests ---
    @Test
    void testGroceryExpiryDate() {
        assertEquals("2025-12-01", milk.getExpiryDate());
    }

    @Test
    void testGroceryReport() {
        String report = milk.getReport();
        assertTrue(report.contains("Milk"));
        assertTrue(report.contains("25"));
        assertTrue(report.contains("Expiry"));
    }
}
